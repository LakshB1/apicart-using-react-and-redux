import {ADD_DATA, DELETE_DATA} from '../action';

export const addtocart = ()=>
{
    return {
         type : ADD_DATA,
    }
}

export const deleterecord = ()=>
{
    return {
         type : DELETE_DATA,
    }
}